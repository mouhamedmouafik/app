const redis = require('redis');

// Configuration du client Redis
let redisClient;

(async () => {
  redisClient = redis.createClient({
    host: 'localhost',
    port: 6379,
    // Autres options si nécessaires
  });

  // Gestion manuelle de la connexion avec .connect()
  redisClient.connect();

  redisClient.on('error', (error) => {
    console.error('Erreur Redis :', error);
  });

  redisClient.on('connect', () => {
    console.log('Client Redis connecté');
  });

  // D'autres configurations ou gestionnaires d'événements peuvent être ajoutés ici
})();

// Exportation du client Redis
module.exports = redisClient;