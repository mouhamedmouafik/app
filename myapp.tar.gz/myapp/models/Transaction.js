const mongoose = require('mongoose');

// Définir le schéma pour les transactions
const transactionSchema = new mongoose.Schema({
    transaction_id: {
        type: String,
        required: true,
        unique: true
    },
    timestamp: {
        type: Date,
        required: true
    },
    customer_id: {
        type: String,
        required: true
    },
    customer_name: {
        type: String,
        required: true
    },
    product_id: {
        type: String,
        required: true
    },
    product_name: {
        type: String,
        required: true
    },
    category: {
        type: String,
        required: true
    },
    quantity: {
        type: Number,
        required: true
    },
    price_per_unit: {
        type: Number,
        required: true
    },
    total_price: {
        type: Number,
        required: true
    },
    payment_method: {
        type: String,
        required: true
    },
    location: {
        type: String,
        required: true
    }
});

// Spécifiez le nom de la collection comme deuxième argument du modèle
const Transaction = mongoose.model('Transaction', transactionSchema, 'transaction');

module.exports = Transaction;

