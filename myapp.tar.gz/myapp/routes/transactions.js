// transactions.js

const express = require('express');
const router = express.Router();
const Transaction = require('../models/Transaction');
const redisClient = require('../cache');

// GET d'une transaction par ID
router.get('/:id', async (req, res) => {
    try {
        const transactionId = req.params.id;

        // Tentative de récupération depuis Redis
        const cachedTransaction = await redisClient.get(`transaction:${transactionId}`);
        if (cachedTransaction) {
            console.log(`Récupération de la transaction ${transactionId} depuis le cache`);
            res.json(JSON.parse(cachedTransaction));
        } else {
            const transaction = await Transaction.findById(transactionId);
            if (!transaction) {
                return res.status(404).json({ message: 'Transaction non trouvée' });
            }
            // Mettre les données en cache dans Redis
            redisClient.set(`transaction:${transactionId}`, JSON.stringify(transaction), 'EX', 3600);
            res.json(transaction);
        }
    } catch (err) {
        console.error('Erreur lors de la récupération de la transaction :', err);
        res.status(500).json({ message: 'Erreur interne du serveur' });
    }
});

module.exports = router;
